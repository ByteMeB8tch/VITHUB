"use client"

import { Suspense, useState } from "react"
import DashboardLayout from "@/components/dashboard/layout"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Search, MessageCircle, ThumbsUp } from "lucide-react"

const announcements = [
  {
    id: 1,
    title: "Campus Library Extended Hours",
    category: "Academic",
    content: "The main library will now be open 24/7 during exam season starting next week.",
    author: "Library Director",
    timestamp: "2 hours ago",
    likes: 12,
    comments: 3,
  },
  {
    id: 2,
    title: "Emergency Maintenance Alert",
    category: "Emergency",
    content: "Scheduled maintenance on East Campus will occur on Friday, Jan 17 from 2-4 PM.",
    author: "Campus Operations",
    timestamp: "4 hours ago",
    likes: 8,
    comments: 5,
  },
  {
    id: 3,
    title: "Annual Campus Club Fair",
    category: "Event",
    content: "Join us for the biggest club fair of the year! Over 100 clubs will be participating.",
    author: "Student Affairs",
    timestamp: "1 day ago",
    likes: 45,
    comments: 12,
  },
  {
    id: 4,
    title: "New Scholarship Opportunities",
    category: "Academic",
    content: "Applications are now open for spring semester scholarships. Deadline is January 31.",
    author: "Financial Aid Office",
    timestamp: "2 days ago",
    likes: 28,
    comments: 7,
  },
]

const categories = ["All", "Academic", "Events", "Clubs", "Emergency"]

function AnnouncementsContent() {
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [searchTerm, setSearchTerm] = useState("")

  const filteredAnnouncements = announcements.filter((ann) => {
    const matchesCategory = selectedCategory === "All" || ann.category === selectedCategory
    const matchesSearch =
      ann.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ann.content.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesCategory && matchesSearch
  })

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      Academic: "bg-blue-500/20 text-blue-400 border-blue-500/30",
      Event: "bg-purple-500/20 text-purple-400 border-purple-500/30",
      Clubs: "bg-pink-500/20 text-pink-400 border-pink-500/30",
      Emergency: "bg-red-500/20 text-red-400 border-red-500/30",
    }
    return colors[category] || "bg-accent/20 text-accent border-accent/30"
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Announcements & Communications</h1>
        <p className="text-foreground/60">Stay updated with the latest campus news and announcements</p>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-foreground/40" />
          <Input
            placeholder="Search announcements..."
            className="pl-10 bg-card/50 border-border/60"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {/* Category Filters */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {categories.map((cat) => (
          <Button
            key={cat}
            variant={selectedCategory === cat ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedCategory(cat)}
            className={
              selectedCategory === cat ? "bg-accent hover:bg-accent/90 text-accent-foreground" : "border-border/60"
            }
          >
            {cat}
          </Button>
        ))}
      </div>

      {/* Announcements Grid */}
      <div className="space-y-4">
        {filteredAnnouncements.length > 0 ? (
          filteredAnnouncements.map((ann) => (
            <Card
              key={ann.id}
              className="bg-card/50 border-border/60 hover:border-accent/40 hover:bg-card/70 transition-smooth"
            >
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-3">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold">{ann.title}</h3>
                      <Badge className={getCategoryColor(ann.category)}>{ann.category}</Badge>
                    </div>
                    <p className="text-sm text-foreground/60">
                      {ann.author} • {ann.timestamp}
                    </p>
                  </div>
                </div>
                <p className="text-foreground/80 mb-4">{ann.content}</p>
                <div className="flex gap-4 text-sm text-foreground/60">
                  <button className="flex items-center gap-1 hover:text-accent transition-colors">
                    <ThumbsUp className="h-4 w-4" />
                    {ann.likes}
                  </button>
                  <button className="flex items-center gap-1 hover:text-accent transition-colors">
                    <MessageCircle className="h-4 w-4" />
                    {ann.comments}
                  </button>
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          <Card className="bg-card/50 border-border/60">
            <CardContent className="p-12 text-center">
              <p className="text-foreground/60">No announcements found. Try a different search.</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

export default function AnnouncementsPage() {
  return (
    <DashboardLayout>
      <Suspense fallback={<div className="text-foreground/60">Loading announcements...</div>}>
        <AnnouncementsContent />
      </Suspense>
    </DashboardLayout>
  )
}
